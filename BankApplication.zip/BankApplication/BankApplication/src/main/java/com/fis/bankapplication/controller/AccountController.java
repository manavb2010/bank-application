package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.TransService;

@RestController      // using restcontroller to create RESTful web services using Spring MVC
@RequestMapping("/accounts")     // used to map web requests onto specific handler classes or handler methods
public class AccountController {

	@Autowired         // used for automatic dependency injection
	AccountService service;
	@Autowired
	TransService transService;

	@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount  // used to map HTTP POST requests onto specific handler methods
	public String addAccount(@RequestBody @Validated Account account) { // using @RequestBody to map the HttpRequest body to a transfer 
		return service.addAccount(account);    // calling service methods to initiate dispatcherServelet
	}
	
	@PutMapping("/updateAccount")
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}

	@GetMapping("/getAccount") // http://localhost:8080/accounts/getAccount  // used to map HTTP GET requests onto specific handler methods
	public Account getAccount(@RequestBody long accNo) throws AccountNotFound{
		return service.getAccount(accNo);
	}
	
	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public List<Account> getAllAccounts() {
		return service.getAllAccounts();
	}
	
	@GetMapping("/getAllTransOfAcc") // http://localhost:8080/accounts/getAllTransOfAcc
	public Object getAllTransOfAcc(@RequestBody long getAcc){
		return transService.getAllTransOfAcc(getAcc);    // using transService methods to initiate dispatcherServelet
	}
	
	@PutMapping("/transactions/fundTransfer/{transType}") // http://localhost:8080/accounts/transactions/fundTransfer/transType
	public String fundTransferType (@PathVariable("transType") String transType, @RequestBody Transaction transaction) {
		if (transType.equalsIgnoreCase("neft")) {
			return transService.fundTransferNEFT(transaction);       // using if else for different types of fund transfer
		}
		else if (transType.equalsIgnoreCase("rtgs")) {				// using equalsIgnoreCase to check fund transfer type
			return transService.fundTransferRTGS(transaction);
		}
		else if (transType.equalsIgnoreCase("imps")) {
			return transService.fundTransferIMPS(transaction);
		}
		else {
			return "Wrong Transaction Type...";						// else case for wrong transaction type
		}
	}

	@PutMapping("/withdrawFromBalance/{accno}/{amount}") // http://localhost:8080/accounts/withdrawFromAccount/101/40000
	//used to map HTTP PUT requests onto specific handler methods
	public String withdrawFromBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double withdrawAmount) {
		// using @PathVariable to retrieve data from the URL path
		return service.withdrawFromBalance(getAcc, withdrawAmount);
	}
	
	@PutMapping("/depositIntoBalance/{accno}/{amount}") // http://localhost:8080/accounts/depositIntoBalance
	public String depositIntoBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double depositAmount) {
		// using multiple @PathVariable variables
		return service.depositIntoBalance(getAcc, depositAmount);
	}
	
	@DeleteMapping("/deleteAccount") // http://localhost:8080/accounts/deleteAccount
	// used to map HTTP DELETE requests onto specific handler methods
	public String deleteAccount(@RequestBody long getAcc) {
		return service.deleteAccount(getAcc);
	}
	
}
