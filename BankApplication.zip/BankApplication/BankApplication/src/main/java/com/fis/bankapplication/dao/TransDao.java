package com.fis.bankapplication.dao;

import com.fis.bankapplication.model.Transaction;

public interface TransDao {

	public abstract Object getAllTransOfAcc(long getAcc);

	public abstract String fundTransferNEFT(Transaction transaction);

	public abstract String fundTransferRTGS(Transaction transaction);

	public abstract String fundTransferIMPS(Transaction transaction);
}
