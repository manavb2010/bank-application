package com.fis.bankapplication.service;

import java.util.List;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;

public interface AccountService {
	public abstract String addAccount(Account account);
	
	public abstract String updateAccount(Account account);
	
	public abstract Account getAccount(long accNo) throws AccountNotFound;
//	
	public abstract String withdrawFromBalance(long getAcc, double withdrawAmount);
	
	public abstract String depositIntoBalance(long getAcc, double depositAmount);
	
	public abstract String deleteAccount(long getAcc);
	
	public abstract List<Account> getAllAccounts();
}
