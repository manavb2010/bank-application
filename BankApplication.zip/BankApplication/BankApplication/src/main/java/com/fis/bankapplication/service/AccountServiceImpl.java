package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	AccountDao dao;

	@Override
	public String addAccount(Account account) {
		dao.save(account);
		return "Account added Successfully";
	}

	@Override
	public Account getAccount(long accNo) throws AccountNotFound {
		Optional<Account> optional = dao.findById(accNo);
		if(optional.isPresent()) {
			return optional.get();
		}
		else {
			throw new AccountNotFound("Account Number is invalid...");
		}
	}

	@Override
	public String withdrawFromBalance(long getAcc, double withdrawAmount) {
		dao.withdrawFromBalance(getAcc, withdrawAmount);
		return "Withdrawn Successfully";
	}

	@Override
	public String depositIntoBalance(long getAcc, double depositAmount) {
		dao.depositIntoBalance(getAcc, depositAmount);
		return "Deposited Successfully";
	}

	@Override
	public String deleteAccount(long getAcc) {
		dao.deleteById(getAcc);
		return "Account deleted Successfully...";
	}

	@Override
	public List<Account> getAllAccounts() {
		return dao.findAll();
	}

	@Override
	public String updateAccount(Account account) {
		dao.save(account);
		return "Account updated Successfully";
	}
	
	
}
