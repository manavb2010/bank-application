package com.fis.bankapplication.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.TransDao;
import com.fis.bankapplication.model.Transaction;

@Service	// used to mark the class as a service provider
@Transactional 		// used to mark a method or a class as transactional 
public class TransServiceImpl implements TransService{
	@Autowired
	TransDao dao;        // using DATA ACCESS OBJECT FOR ACCESSING REPOSITORY

	@Override
	public Object getAllTransOfAcc(long getAcc) {
		return dao.getAllTransOfAcc(getAcc);
	}

	@Override
	public String fundTransferNEFT(Transaction transaction) {
		return dao.fundTransferNEFT(transaction);
	}

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		return dao.fundTransferRTGS(transaction);
	}

	@Override
	public String fundTransferIMPS(Transaction transaction) {
		return dao.fundTransferIMPS(transaction);
	}

}
