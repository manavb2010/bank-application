package com.fis.bankapplication.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Value;

@Entity      // defines that a class can be mapped to a table
@Table(name = "accounts_info") // specifies the name of the database table to be used for mapping
public class Account {
	@Id 				// indicates the member field below is the primary key of the current entity
	@Min(value = 1000, message = "Account Number cannot be less than 1000.")
	@Max(value = 10000, message = "Account Number cannot be more than 10000.")
	@NotBlank(message = "Account Number cannot be null or whitespace.")
	private long accNo;
	@Size(min = 6, max = 15, message = "Account Holder Name must be 6 - 15 letters long.")
	@NotBlank(message = "Account Holder Name cannot be null or whitespace.")
	private String custName;
	@Size(min = 10, max = 10, message= "Phone Number cannot be less than or greater than 10 digits long.")
	@NotBlank(message = "Phone Number cannot be null or whitespace.")
	private long mobile;
	@Value(value = "Saving")
	private String accType;
	@NotBlank(message = "Branch cannot be null or whitespace.")
	private String branch;
	@Max(value = 99999999, message = "Account Balance cannot exceed 10 crores.")
	private double balance;
	
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Account(
			@Min(value = 1000, message = "Account Number cannot be less than 1000.") @Max(value = 10000, message = "Account Number cannot be more than 10000.") @NotBlank(message = "Account Number cannot be null or whitespace.") long accNo,
			@Size(min = 6, max = 15, message = "Account Holder Name must be 6 - 15 letters long.") @NotBlank(message = "Account Holder Name cannot be null or whitespace.") String custName,
			@Size(min = 10, max = 10, message = "Phone Number cannot be less than or greater than 10 digits long.") @NotBlank(message = "Phone Number cannot be null or whitespace.") long mobile,
			String accType, @NotBlank(message = "Branch cannot be null or whitespace.") String branch,
			@Max(value = 99999999, message = "Account Balance cannot exceed 10 crores.") double balance) {
		super();
		this.accNo = accNo;
		this.custName = custName;
		this.mobile = mobile;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
	}
	public Account() {
		super();
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", custName=" + custName + ", mobile=" + mobile + ", accType=" + accType
				+ ", branch=" + branch + ", balance=" + balance + "]";
	}
	

}
