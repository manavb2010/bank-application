package com.fis.bankapplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankapplication.model.Account;

public interface AccountDao extends JpaRepository<Account, Long> {


	@Query("Update Account a set a.balance = a.balance - ?2 where a.accNo = ?1")
	@Modifying
	public void withdrawFromBalance(long getAcc, double withdrawAmount);

	@Query("Update Account a set a.balance = a.balance + ?2 where a.accNo = ?1")
	@Modifying
	public void depositIntoBalance(long getAcc, double depositAmount);


}
