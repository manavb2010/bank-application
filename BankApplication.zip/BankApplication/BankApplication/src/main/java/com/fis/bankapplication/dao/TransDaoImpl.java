package com.fis.bankapplication.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;

@Repository    // used to indicate that the class provides the mechanism for CRUD operation on objects.
public class TransDaoImpl implements TransDao{
	@PersistenceContext		// handles a set of entities which hold data to be persisted in a database
	EntityManager entityManager;  // an API that manages the life cycle of entity instances

	@Override
	public Object getAllTransOfAcc(long getAcc) {
		
		try {
			if(entityManager.find(Account.class, getAcc) != null) {
				TypedQuery<Transaction> query = entityManager.createQuery("select trans from Transaction trans where trans.accNoTo = ?1 or trans.accNoFrom = ?1", Transaction.class);
				query.setParameter(1, getAcc);
				return query.getResultList();
			}
			else {
				throw new AccountNotFound("Account not Found.");
			}
		}catch (AccountNotFound anf) {
			return "Account Not Found";
		}
	}

	@Override
	public String fundTransferNEFT (Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());		// used to find an entity in the database using primary key
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		if (acc1.getBalance() - transaction.getAmount() >= 0) {
			if(transaction.getTransType().equalsIgnoreCase("neft")) {
				acc1.setBalance(acc1.getBalance() - transaction.getAmount());
				acc2.setBalance(acc2.getBalance() + transaction.getAmount());
				entityManager.persist(transaction);		// used to insert a new object into the database
				return "NEFT Transaction performed Successfully...";
			}
			else {
				return "Transaction Failed.";
			}
		}
		else {
			return "Transaction Failed.";
		}
		
	}

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		if (acc1.getBalance() - transaction.getAmount() >= 0) {
			if(transaction.getTransType().equalsIgnoreCase("rtgs")) {
				acc1.setBalance(acc1.getBalance() - transaction.getAmount());
				acc2.setBalance(acc2.getBalance() + transaction.getAmount());
				entityManager.persist(transaction);
				return "RTGS Transaction performed Successfully...";
			}
			else {
				return "Transaction Failed.";
			}
		}
		else {
			return "Transaction Failed.";
		}
	}

	@Override
	public String fundTransferIMPS(Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		if (acc1.getBalance() - transaction.getAmount() >= 0) {
			if(transaction.getTransType().equalsIgnoreCase("imps")) {
				acc1.setBalance(acc1.getBalance() - transaction.getAmount());
				acc2.setBalance(acc2.getBalance() + transaction.getAmount());
				entityManager.persist(transaction);
				return "IMPS Transaction performed Successfully...";
			}
			else {
				return "Transaction Failed.";
			}
		}
		else {
			return "Transaction Failed.";
		}
	}
	
}
