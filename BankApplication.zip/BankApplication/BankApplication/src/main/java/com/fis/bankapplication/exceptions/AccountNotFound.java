package com.fis.bankapplication.exceptions;

public class AccountNotFound extends Exception{ //exception handling for account not found
	public AccountNotFound(String message) {
		super(message);
	}
}