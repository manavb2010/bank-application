package com.fis.BankAppCustomers.exceptions;

public class NoCustomersFound extends RuntimeException{


	public NoCustomersFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
