//package com.fis.BankClient.repo;
//
//import org.springframework.data.repository.CrudRepository;
//
//import org.springframework.stereotype.Repository;
//
//import com.fis.BankClient.model.DAOUser;
//
//@Repository
//public interface UserDao extends CrudRepository<DAOUser, Integer> {
//	
//	DAOUser findByUsername(String username);
//	
//}
//package com;
//
