package com.fis.BankAppCustomers.model;


import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name = "customer_info")
public class Customer {
	@Id
	private int customerId;
	@Size(min = 3, max = 15, message = "Name must be between 3-15.")
	@NotBlank(message = "Name cannot be null or whitespace.")
	private String customerName;
	@Digits(fraction = 0, integer = 10, message  = "Phone number should be 10 digits.")
	private long mobileNo;
	@Email(message = "Email format should have @ and .")
	private String emailId;
	@Digits(fraction = 0, integer = 12 , message = "Aadhar Card Number should be 12 digits.")
	private long aadharCard;
	@Past(message = "Date of Birth cannot be current date.")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dob;
	@Positive
	@Min(value = 18, message ="Must be atleast 18 to open an account.")
	private short age;
	@NotEmpty(message = "This field cannot be empty.")
	private String address;
	@Size(min = 5, max = 20, message = "Length of password must be between 5-20.")
	@NotBlank(message = "Password cannot be null or whitespace.")
	private String password;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getAadharCard() {
		return aadharCard;
	}
	public void setAadharCard(long aadharCard) {
		this.aadharCard = aadharCard;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public short getAge() {
		return age;
	}
	public void setAge(short age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", mobileNo=" + mobileNo
				+ ", emailId=" + emailId + ", aadharCard=" + aadharCard + ", dob=" + dob + ", age=" + age + ", address="
				+ address + ", password=" + password + "]";
	}
	public Customer(int customerId,
			@Size(min = 3, max = 15, message = "Name must be between 3-15.") @NotBlank(message = "Name cannot be null or whitespace.") String customerName,
			@Digits(fraction = 0, integer = 10, message = "Phone number should be 10 digits.") long mobileNo,
			@Email(message = "Email format should have @ and .") String emailId,
			@Digits(fraction = 0, integer = 12, message = "Aadhar Card Number should be 12 digits.") long aadharCard,
			@Past(message = "Date of Birth cannot be current date.") Date dob,
			@Positive @Min(value = 18, message = "Must be atleast 18 to open an account.") short age,
			@NotEmpty(message = "This field cannot be empty.") String address,
			@Size(min = 5, max = 20, message = "Length of password must be between 5-20.") @NotBlank(message = "Password cannot be null or whitespace.") String password) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.aadharCard = aadharCard;
		this.dob = dob;
		this.age = age;
		this.address = address;
		this.password = password;
	}
	
	
}