package com.fis.BankAppCustomers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppCustomersApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppCustomersApplication.class, args);
	}

}
