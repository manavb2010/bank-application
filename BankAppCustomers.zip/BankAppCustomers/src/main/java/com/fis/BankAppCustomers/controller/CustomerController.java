package com.fis.BankAppCustomers.controller;


import java.util.List;

//import java.util.Map;

//import javax.ws.rs.Path;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.BankAppCustomers.model.Customer;
import com.fis.BankAppCustomers.model.CustomerDTO;
import com.fis.BankAppCustomers.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService service;
		
	@GetMapping("/customer")
	public ResponseEntity<CustomerDTO> customer(){
		List<Customer> list= service.getAllCustomers();
		CustomerDTO dto=new CustomerDTO();
		dto.setList(list);
		return new ResponseEntity<CustomerDTO>(dto,HttpStatus.OK);
		
	}
	
	@PostMapping("/addCustomer")
	public ResponseEntity<Object> addCustomer(@RequestBody Customer acc){
		if(service.addCustomer(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping("/deleteCustomer/{customerId}")
	public ResponseEntity<Object> deleteCustomer(@PathVariable("customerId") int customerId){
		service.deleteCustomer(customerId);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
	
	
}
