package com.fis.BankAppCustomers.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.BankAppCustomers.exceptions.NoCustomersFound;
import com.fis.BankAppCustomers.model.Customer;
import com.fis.BankAppCustomers.repo.CustomerRepo;

//This is used to call CustomerRepo.

@Service
@Transactional
public class CustomerService {

	@Autowired
	private CustomerRepo dao;

	public List<Customer> getAllCustomers() {

		List<Customer> list = dao.findAll();
		if (list.isEmpty()) {
			return null;
		} else
			return list;
	}

	public boolean addCustomer(Customer customer) {
		Customer cus = dao.save(customer);
		if (cus != null)
			return true;
		else
			return false;
	}

	public boolean deleteCustomer(int customerId) {
		Optional<Customer> optional = dao.findById(customerId);
		Customer customer = optional.get();
		if (customer != null) {
			dao.deleteById(customerId);
			return true;
		} else {
			throw new NoCustomersFound("No Customer to delete");
		}
	}
}
