package com.fis.BankAppCustomers.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.BankAppCustomers.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {

//	public abstract Customer findByCustomerId(int customerId);

}
