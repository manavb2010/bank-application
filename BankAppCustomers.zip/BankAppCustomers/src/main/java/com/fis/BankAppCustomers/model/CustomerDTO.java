package com.fis.BankAppCustomers.model;

import java.util.List;

public class CustomerDTO {

	private List<Customer> list;

	@Override
	public String toString() {
		return "CustomerDTO [list=" + list + "]";
	}

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}
}
