package com.fis.BankAppCustomers;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.fis.BankAppCustomers.model.Customer;
import com.fis.BankAppCustomers.repo.CustomerRepo;
import com.fis.BankAppCustomers.service.CustomerService;

@SpringBootTest
class BankAppCustomersApplicationTests {

	@Test
	void contextLoads() {
	}

	@Autowired
	CustomerService service;
	@MockBean
	CustomerRepo dao;

	@Test
	public void testAddCustomer() {
		Customer cus = new Customer();
		Mockito.when(dao.save(cus)).thenReturn(cus);
		boolean msg = service.addCustomer(cus);
		assertEquals(true, msg);
	}

	@Test
	public void testGetAllCustomers() {
		Customer cus1 = new Customer(100, "manav1", 9876543210l, "manav@fis.com", 987654321098l, new Date(), (short)22, "chd", "manav123");
		Customer cus2 = new Customer(101, "manav1", 9876543210l, "manav@fis.com", 987654321098l, new Date(), (short)22, "chd", "manav123");
		
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(cus1);
		customers.add(cus2);
		System.out.println(customers);
		customers = service.getAllCustomers();
//		List<Customer> customers1 = service.getAllCustomers();

		assertEquals(customers.size(),2);
	}

	@Test
	public void testDeleteCustomer() {
		Customer customer = new Customer();
		Mockito.when(dao.save(customer)).thenReturn(customer);
		Mockito.doNothing().when(service.deleteCustomer(customer.getCustomerId()));
		boolean msg = service.deleteCustomer(customer.getCustomerId());
		assertEquals(true, msg);
	}

}
