package com.fis.bankapplication.exceptions;

@SuppressWarnings("serial")
public class WrongPassword extends RuntimeException {
	// this exception comes when password is incorrect 
	public WrongPassword(String message) {
		super(message);
	}

}
