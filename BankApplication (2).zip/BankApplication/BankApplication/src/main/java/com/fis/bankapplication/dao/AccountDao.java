package com.fis.bankapplication.dao;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.model.Account;

@Repository
public interface AccountDao extends CrudRepository<Account, Long> {

	@Modifying
	@Query("Update Account acc set acc.pass = ?2 where acc.accNo = ?1")
	public abstract int updatePassword(long accNo, String newPass);

	@Modifying
	@Query("Update Account acc set acc.balance = acc.balance + ?2 where acc.accNo = ?1")
	public abstract int depositIntoAcc(long accNo, double amt) throws AccountNotFound;

	public abstract Account findByAccNo(long accNo);

	@Modifying
	@Query("Update Account acc set acc.balance = acc.balance - ?2 where acc.accNo = ?1")
	public abstract int withdrawFromAcc(long accNo, double amount) throws AccountNotFound, NotEnoughBalance;

}
