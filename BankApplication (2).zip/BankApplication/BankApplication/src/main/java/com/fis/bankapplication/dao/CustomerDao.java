package com.fis.bankapplication.dao;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankapplication.model.Customer;

public interface CustomerDao extends JpaRepository<Customer, Integer> {

	public abstract Optional<Customer> findByEmail(String email);
	
	@Modifying
	@Query("Delete Customer cust where cust.customerId = ?1 and cust.pass = ?2")
	public abstract int deleteAcc(int id, String password);

}