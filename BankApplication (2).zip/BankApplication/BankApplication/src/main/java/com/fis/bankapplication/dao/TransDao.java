package com.fis.bankapplication.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.bankapplication.model.Transaction;

public interface TransDao extends JpaRepository<Transaction, Integer>{
	
	public abstract List<Transaction> findByDateOfTransBetween(LocalDate startDate, LocalDate endDate);

	public abstract List<Transaction> findAllByAccNoTo(long accNo);
	
}
