package com.fis.bankapplication.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.TransDao;
import com.fis.bankapplication.model.Transaction;

@Service
@Transactional
public class TransService{
	@Autowired
	TransDao dao;

	
	public String addTransaction(Transaction trans) {
		dao.save(trans);
		return "Transaction saved sucessfully.";
	}
	
	public List<Transaction> getAllTransByDate(String startDate, String endDate) {
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate startDatestr = LocalDate.parse(startDate, dtFormatter);
		LocalDate endDatestr = LocalDate.parse(endDate, dtFormatter);
		return dao.findByDateOfTransBetween(startDatestr, endDatestr);
	}
	
	public List<Transaction> getAllTrans() {
		return dao.findAll();
	}
	
	public List<Transaction> allTransOfAcc(long accNo) {
		return dao.findAllByAccNoTo(accNo);
	}

	

}
