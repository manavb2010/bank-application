package com.fis.bankapplication.exceptions;

@SuppressWarnings("serial")
public class NotEnoughBalance extends RuntimeException {
	
	public NotEnoughBalance(String message) {
		super(message);
	}

}
