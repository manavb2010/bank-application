package com.fis.bankapplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Account;

@Service
public class AccountService {
	@Autowired
	AccountDao dao;

	public String addAccount(Account account) {
		dao.save(account);
		return "Account created Successfully.";
	}

	public boolean validate(long accNo, String password) throws AccountNotFound, WrongPassword {
		Optional<Account> optional = dao.findById(accNo);
		if (optional.isEmpty())
			throw new AccountNotFound("Account not Found...");
		else if (!optional.get().getPass().equals(password))
			throw new WrongPassword("Password Incorrect...");

		else
			return true;
	}

	public String updatePassword(long accNo, String newPass, String confirmPass) {
		if (newPass.equals(confirmPass)) {
			dao.updatePassword(accNo, newPass);
			return "Password Updated Succesfully...";
		}

		else
			return "Passwords do not match...";

	}

	public Account depositIntoAcc(long accNo, double amount) throws AccountNotFound {
		dao.depositIntoAcc(accNo, amount);
		return (dao.findByAccNo(accNo));
	}

	public Account withdrawFromAcc(long accNo, double amount) throws AccountNotFound, NotEnoughBalance {
		Account acc = dao.findByAccNo(accNo);
		if (acc == null)
			throw new AccountNotFound("Account Not Found...");
		if (acc.getBalance() < amount)
			throw new NotEnoughBalance("Not Enough Balance...");
		dao.withdrawFromAcc(accNo, amount);
		return (dao.findByAccNo(accNo));
	}
}
