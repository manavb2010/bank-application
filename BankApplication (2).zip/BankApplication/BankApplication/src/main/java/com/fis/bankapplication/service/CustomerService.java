package com.fis.bankapplication.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Customer;

@Service
@Transactional
public class CustomerService {
	
	@Autowired
	CustomerDao dao;

	public String register(Customer customer) {
		dao.save(customer);
		return "Customer Account Saved Sucessfully...";
	}

	public boolean login(String email, String pass) throws AccountNotFound, WrongPassword {
		Optional<Customer> optional= dao.findByEmail(email);
		if(optional.isEmpty())
			throw new AccountNotFound("Customer Account Not Found...");
		else if(!optional.get().getPass().equals(pass))
			throw new WrongPassword("Account Password is Incorrect...");
			
		else 
			return true;
	}
	
	public String updateAcc(Customer customer) {
		dao.save(customer);
		return "Customer Account Updated Succesfully";
	}
	
	public String deleteAcc(int id, String password)  throws WrongPassword {
		if(dao.deleteAcc(id, password) ==0) {
			throw new WrongPassword("Account Password is Incorrect...");
		};
		return "Customer Account Deleted Successfully...";
	}
}