package com.fis.bankapplication.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

@Entity      // defines that a class can be mapped to a table
@Table(name = "accounts_info") // specifies the name of the database table to be used for mapping
public class Account {
	@Id 				// indicates the member field below is the primary key of the current entity
	@GeneratedValue
	private long accNo;
	@NotBlank(message = "Account Type cannot be null or whitespace.")
	private String accType;
	@NotBlank(message = "Branch Name cannot be null or whitespace.")
	private String branch;
	@PositiveOrZero(message = "Balance must be greater than or equal to zero.")
	private double balance;
	@Size(min = 5, max = 20, message = "Length of password must be between 5-20.")
	private String pass;
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accType=" + accType + ", branch=" + branch + ", balance=" + balance
				+ ", pass=" + pass + "]";
	}
	public Account(long accNo, @NotBlank(message = "Account Type cannot be null or whitespace.") String accType,
			@NotBlank(message = "Branch Name cannot be null or whitespace.") String branch,
			@PositiveOrZero(message = "Balance must be greater than or equal to zero.") double balance,
			@Size(min = 5, max = 20, message = "Length of password must be between 5-20.") String pass) {
		super();
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.balance = balance;
		this.pass = pass;
	}
	public Account() {
		super();
	}
	
	
}
