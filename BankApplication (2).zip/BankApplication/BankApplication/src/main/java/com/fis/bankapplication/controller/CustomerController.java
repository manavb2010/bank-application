package com.fis.bankapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

//{
//  "accHolderName" : "Manav",
//  "mobile" : 9898989898,
//  "email": "abc@fis.com",
//  "aadharCard": 999999999999,
//  "dob": "2001-10-20",
//  "age" : 22,
//  "address" : "Chandigarh",
//  "pass" : "abcde" 
//
//  }

@RestController      // using restcontroller to create RESTful web services using Spring MVC
@RequestMapping("/main-menu")     // used to map web requests onto specific handler classes or handler methods
public class CustomerController {
	
	@Autowired
	CustomerService service;

	@PostMapping("/register") // http://localhost:8080/main-menu/register
	public String register(@RequestBody Customer customer) {
		return service.register(customer);
	}
	
	@GetMapping("/login/{email}/{pass}") // http://localhost:8080/main-menu/login
	public String login(@PathVariable("email") String email, @PathVariable("pass") String pass) {
		try {
			service.login(email, pass);
			return "redirect:/CustomerAccount";
		} catch (AccountNotFound | WrongPassword e) {
			System.out.println("Exception Found " + e );
		}
		return "redirect:/Register";

	}
	
	@PutMapping("/updateAcc") // http://localhost:8080/main-menu/updateAcc
	public String updateAcc(@RequestBody Customer customer) {
		return service.updateAcc(customer);
	}
	
	@DeleteMapping("/deleteAcc/{id}/{pass}") // http://localhost:8080/main-menu/deleteAcc
	public String deleteAcc(@PathVariable("id") int id, @PathVariable("pass") String pass) {
		try{
			return service.deleteAcc(id, pass);		
		}catch(WrongPassword p) {
			return "Pasword in Incorrect...";
		}
	}

//	
//	@PutMapping("/updateAccount")
//	public String updateAccount(@RequestBody Account account) {
//		return service.updateAccount(account);
//	}
//
//	@GetMapping("/getAccount/{accNo}") // http://localhost:8080/accounts/getAccount  // used to map HTTP GET requests onto specific handler methods
//	public Account getAccount(@PathVariable("accNo") long accNo){
//		return service.getAccount(accNo);
//	}
//	
//	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
//	public List<Account> getAllAccounts() {
//		return service.getAllAccounts();
//	}
//	
//	
//	
////	@GetMapping("/getAllTransOfAcc") // http://localhost:8080/accounts/getAllTransOfAcc
////	public Object getAllTransOfAcc(@RequestBody long getAcc){
////		return transService.getAllTransOfAcc(getAcc);    // using transService methods to initiate dispatcherServelet
////	}
////	
////	@PutMapping("/transactions/fundTransfer/{transType}") // http://localhost:8080/accounts/transactions/fundTransfer/transType
////	public String fundTransferType (@PathVariable("transType") String transType, @RequestBody Transaction transaction) {
////		if (transType.equalsIgnoreCase("neft")) {
////			return transService.fundTransferNEFT(transaction);       // using if else for different types of fund transfer
////		}
////		else if (transType.equalsIgnoreCase("rtgs")) {				// using equalsIgnoreCase to check fund transfer type
////			return transService.fundTransferRTGS(transaction);
////		}
////		else if (transType.equalsIgnoreCase("imps")) {
////			return transService.fundTransferIMPS(transaction);
////		}
////		else {
////			return "Wrong Transaction Type...";						// else case for wrong transaction type
////		}
////	}
////
////	@PutMapping("/withdrawFromBalance/{accNo}/{amount}") // http://localhost:8080/accounts/withdrawFromAccount/101/40000
////	//used to map HTTP PUT requests onto specific handler methods
////	public String withdrawFromBalance(@PathVariable("accNo") long getAcc , @PathVariable("amount") double withdrawAmount) {
////		// using @PathVariable to retrieve data from the URL path
////		return service.withdrawFromBalance(getAcc, withdrawAmount);
////	}
////	
////	@PutMapping("/depositIntoBalance/{accNo}/{amount}") // http://localhost:8080/accounts/depositIntoBalance
////	public String depositIntoBalance(@PathVariable("accNo") long getAcc , @PathVariable("amount") double depositAmount) {
////		// using multiple @PathVariable variables
////		return service.depositIntoBalance(getAcc, depositAmount);
////	}
//	
//	@DeleteMapping("/deleteAccount/{accNo}") // http://localhost:8080/accounts/deleteAccount
//	// used to map HTTP DELETE requests onto specific handler methods
//	public String deleteAccount(@PathVariable("accNo") long accNo) {
//		return service.deleteAccount(accNo);
//	}
	
}
