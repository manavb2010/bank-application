package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.TransService;

//{
//"accType" : "Savings",
//"branch" : "Chandigarh",
//"balance" : 40000,
//"pass" : "abcde"
//}

@RestController // using restcontroller to create RESTful web services using Spring MVC
@RequestMapping("/accounts") // used to map web requests onto specific handler classes or handler methods
public class AccountController {

	@Autowired // used for automatic dependency injection
	AccountService service;
	@Autowired
	TransService transService;

	@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount // used to map HTTP POST requests
								// onto specific handler methods
	public String addAccount(@RequestBody Account account) { // using @RequestBody to map the HttpRequest body to a
																// transfer
		return service.addAccount(account); // calling service methods to initiate dispatcherServelet
	}

	@GetMapping("/validate/{accNo}/{pass}") // http://localhost:8080/accounts/validate
	public int validate(@PathVariable("accNo") long accNo, @PathVariable("pass") String pass) {
		try {
			service.validate(accNo, pass);
			return 1;
		} catch (AccountNotFound | WrongPassword exc) {
			System.out.println("Exception faced : " + exc);
		}
		return 0;
	}

	@GetMapping("/updatePassword/{accNo}/{pass}/{newPass}/{confirmPass}") // http://localhost:8080/accounts/updatePassword
	public String updatePassword(@PathVariable("accNo") long accNo, @PathVariable("pass") String pass,
			@PathVariable("newPass") String newPass, @PathVariable("confirmPass") String confirmPass) {
		int result = validate(accNo, pass);
		if (result == 0)
			return "Failed, accNo or password does not match ";
		else
			return service.updatePassword(accNo, newPass, confirmPass);

	}

	@GetMapping("/depositIntoAcc/{accNo}/{amount}") // http://localhost:8080/accounts/depositIntoAcc
	public String depositIntoAcc(@PathVariable("accNo") long accNo, @PathVariable("amount") double amount) {
		try {
			Account acc = service.depositIntoAcc(accNo, amount);
			Transaction trans = new Transaction();
			trans.setAccNoFrom(0);
			trans.setAccNoTo(accNo);
			trans.setAmount(amount);
			trans.setBalance(acc.getBalance());
			trans.setTransType("deposit");
			transService.addTransaction(trans);
			return acc.toString();
		} catch (AccountNotFound anf) {
			return "Account Not Found...";
		}
	}

	@GetMapping("/withdrawFromAcc/{accNo}/{pass}/{amount}") // http://localhost:8080/accounts/withdrawFromAcc
	public String withdrawFromAcc(@PathVariable("accNo") long accNo, @PathVariable("pass") String pass,
			@PathVariable("amount") double amount) {
		if (validate(accNo, pass) == 1) {
			try {

				Account acc = service.withdrawFromAcc(accNo, amount);
				Transaction trans = new Transaction();
				trans.setAccNoTo(0);
				trans.setAccNoFrom(accNo);
				trans.setAmount(amount);
				trans.setBalance(acc.getBalance());
				trans.setTransType("withdraw");

				transService.addTransaction(trans);

				return acc.toString();

			} catch (AccountNotFound | NotEnoughBalance exc) {
				return "Exception encountered : " + exc;
			}

		}
		return "Account Not Found or Not Enough Balance... Try Again...";
	}

	@GetMapping("/transfer/{accNoTo}/{accNoFrom}/{pass}/{amount}") // http://localhost:8080/accounts/transfer
	public String transferotherBank(@PathVariable("accNoTo") long accNoTo, @PathVariable("accNoFrom") long accNoFrom,
			@PathVariable("pass") String pass, @PathVariable("amount") double amount) {
		int result = validate(accNoFrom, pass);
		if (result == 0)
			return "Account Number or password incorrect...";
		else {
			try {
				Account acc = service.withdrawFromAcc(accNoFrom, amount);

				Transaction trans = new Transaction();
				trans.setAccNoTo(accNoTo);
				trans.setAccNoFrom(accNoFrom);
				trans.setAmount(amount);
				trans.setBalance(acc.getBalance());
				trans.setTransType("Transfer to another account...");

				transService.addTransaction(trans);

				return acc.toString();
			} catch (AccountNotFound anf) {
				return "Account Not Found...";
			} catch (NotEnoughBalance neb) {
				return "Not Enough Balance...";
			}
		}
	}
	
	@GetMapping("/getAllTrans")  //http://localhost:8080/accounts/getAllTrans
	public List<Transaction>  getAllTrans(){
		return transService.getAllTrans();
	}
	
	@GetMapping("/allTransOfAcc/{accNo}/{pass}")  //http://localhost:8080/accounts/allTransOfAcc
	public List<Transaction>  allTransOfAcc(@PathVariable("accNo") long accNo, @PathVariable("pass") String pass ){
		int result = validate(accNo, pass);
		if(result == 0)
			return null;
		else 
			return transService.allTransOfAcc(accNo);
	}
	
	@GetMapping("/getAllTransByDate/{startdate}/{enddate}")  //http://localhost:8080/accounts/getAllTransByDate
	public List<Transaction> getAllTransByDate( @PathVariable("startdate") String startdate, @PathVariable("enddate") String enddate){
		for (Transaction trans:transService.getAllTransByDate(startdate, enddate)) {
			System.out.println(trans);
		}
			
			return transService.getAllTransByDate(startdate, enddate);
	}
}
