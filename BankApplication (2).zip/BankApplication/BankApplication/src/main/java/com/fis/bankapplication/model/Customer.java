package com.fis.bankapplication.model;


import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
@Table(name = "customer_info")
public class Customer {
	@Id
	@GeneratedValue
	private int customerId;
	@Size(min = 3, max = 20, message = "Length of name must be between 3-20.")
	@NotBlank(message = "Name cannot be null or whitespace.")
	private String accHolderName;
	private long mobile;
	@Email(message = "Email should have '.' and '@'. ")
	private String email;
	@Digits(fraction = 0, integer = 12 , message = "Aadhar Card Number must be 12 digits.")
	private long aadharCard;
	@Past(message = "Date of Birth cannot be today's date.")
	@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "yyyy-MM-dd")
	private LocalDate dob;
	@Positive
	@Min(value = 18, message ="Must be atleast 18 years old to open an account.")
	private short age;
	@NotEmpty(message = "Address cannot be empty.")
	private String address;
	@Size(min = 5, max = 20, message = "Length of Password must be between 5-20. ")
	@NotBlank(message = "Password cannot be null or whitespace")
	private String pass;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getAadharCard() {
		return aadharCard;
	}
	public void setAadharCard(long aadharCard) {
		this.aadharCard = aadharCard;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public short getAge() {
		return age;
	}
	public void setAge(short age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Customer(int customerId,
			@Size(min = 3, max = 20, message = "Length of name must be between 3-20.") @NotBlank(message = "Name cannot be null or whitespace.") String accHolderName,
			long mobile, @Email(message = "Email should have '.' and '@'. ") String email,
			@Digits(fraction = 0, integer = 12, message = "Aadhar Card Number must be 12 digits.") long aadharCard,
			@Past(message = "Date of Birth cannot be today's date.") LocalDate dob,
			@Positive @Min(value = 18, message = "Must be atleast 18 years old to open an account.") short age,
			@NotEmpty(message = "Address cannot be empty.") String address,
			@Size(min = 5, max = 20, message = "Length of Password must be between 5-20. ") @NotBlank(message = "Password cannot be null or whitespace") String pass) {
		super();
		this.customerId = customerId;
		this.accHolderName = accHolderName;
		this.mobile = mobile;
		this.email = email;
		this.aadharCard = aadharCard;
		this.dob = dob;
		this.age = age;
		this.address = address;
		this.pass = pass;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", accHolderName=" + accHolderName + ", mobile=" + mobile
				+ ", email=" + email + ", aadharCard=" + aadharCard + ", dob=" + dob + ", age=" + age + ", address="
				+ address + ", pass=" + pass + "]";
	}
	
	

}
