package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.service.AccountService;

@SpringBootTest
class AccountTests {

	@Autowired
	AccountService service;

	@Test
	public void testAddAccount() {
		Account acc = new Account(1l, "Savings", "Chandigarh", 40000, "abcde");
		String msg = service.addAccount(acc);
		assertEquals("Account Created Sucessfully", msg);
	}

	@Test
	public void testValidate() {
		Boolean flag = null;
		try {
			flag = service.validate(1l, "abcde");
		} catch (AccountNotFound | WrongPassword exc) {
			flag = false;
		}
		assertTrue(flag);
	}

	@Test
	public void testDepositIntoAcc() {
		Account acc;
		try {
			acc = service.depositIntoAcc(1l, 100);
			assertNotNull(acc);
		} catch (AccountNotFound exc) {
			acc = null;
			assertNull(acc);
		}

	}

	@Test
	public void testWithdrawFromAcc() {
		Account acc;
		try {
			acc = service.withdrawFromAcc(1l, 10);
			assertNotNull(acc);
		} catch (AccountNotFound exc) {
			acc = null;
			assertNull(acc);
		}

	}

	@Test
	public void testUpdatePassword() {
		String msg = service.updatePassword(1l, "vwxyz", "vwxyz");
		assertEquals("Password Updated Succesfully", msg);
	}

}
