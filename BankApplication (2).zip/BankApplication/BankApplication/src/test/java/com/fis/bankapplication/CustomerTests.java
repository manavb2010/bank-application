package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.WrongPassword;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@SpringBootTest
class CustomerTests {

	@Autowired
	CustomerService service;

	@Test
	public void testRegister() {
		Customer cus = new Customer(111, "Manav", 9898989898l, "abc@fis.com", 123456789012l,
				LocalDate.ofYearDay(2001, 5), (short) 22, "Chandigarh", "abcde");
		String msg = service.register(cus);
		assertEquals("Customer Account Saved Sucessfully", msg);
	}

	@Test
	public void testLogin() {
		Boolean flag = null;
		try {
			flag = service.login("abc@fis.com", "abcde");
		} catch (AccountNotFound | WrongPassword exc) {
			flag = false;
		}
		assertEquals(true, flag);

	}

	@Test
	public void testDeleteAcc() {
		String msg = null;
		try {
			msg = service.deleteAcc(111, "abcde");
			assertEquals("Customer Account Deleted Successfully", msg);
		} catch (WrongPassword exc) {
			assertEquals(null, msg);
		}

	}

	@Test
	public void testUpdateAcc() {
		Customer cus = new Customer(111, "Manav", 9898989898l, "abc@fis.com", 123456789012l,
				LocalDate.ofYearDay(2001, 5), (short) 22, "Chandigarh", "abcde");
		String msg = service.updateAcc(cus);
		assertEquals("Customer Updated Succesfully", msg);
	}

}
