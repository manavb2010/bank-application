package com.fis.bankapplication;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.TransService;


@SpringBootTest
class TransactionTests {
	
	@Autowired
	TransService service;
	
	@Test
	public void testAddTransaction(){
		Transaction trans= new Transaction(1, 1l, 1l, 10d, LocalDate.now(), "deposit", 10d);
		String msg = service.addTransaction(trans);
		assertEquals("Transaction saved sucessfully", msg);
	}
	
	@Test
	public void testGetAllTrans() {
		Boolean flag = service.getAllTrans().isEmpty();
		assertTrue(flag);
	}
	
	@Test
	public void testGetAllTransactionByAccNo() {
		Boolean flag = service.allTransOfAcc(1l).isEmpty();
		assertTrue(flag);
	}

	@Test
	public void testGetAllTransactionByDate() {
		Boolean flag = service.getAllTransByDate("2023-10-10", "2023-12-12").isEmpty();
		assertTrue(flag);
	}

	
}
